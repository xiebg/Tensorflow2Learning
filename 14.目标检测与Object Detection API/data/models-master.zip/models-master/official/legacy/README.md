Models in this `legacy` directory are mainly are used for benchmarking the
models.

Please note that the models in this `legacy` directory are not supported like
the models in official/nlp and official/vision.
